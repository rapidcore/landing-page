+++
date = "2015-12-2T14:10:00+03:00"
draft = false
title = "Second Post"
weight = 2
+++

Second post
Usage maybe?

```
DoSomething()
```

And the output would be:

```
Something
```
