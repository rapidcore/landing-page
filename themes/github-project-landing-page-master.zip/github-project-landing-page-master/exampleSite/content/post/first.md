+++
date = "2015-12-2T14:10:00+03:00"
draft = false
title = "First Post"
weight = 1
+++

First post
Where you talk about how to install your project

```
brew install amazing-tool
```
